package org.gradle.test.sub;

public interface SubJavaInterface {
}
