package org.gradle.test;

public interface CombinedInterface extends Interface1, Interface2 {
}
